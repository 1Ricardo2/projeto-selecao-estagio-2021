package com.example.projetoLoja;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoLojaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoLojaApplication.class, args);
	}

}
